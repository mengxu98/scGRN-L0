NIMEFI: Gene regulatory network inference using multiple ensemble feature importance algorithms. 2013. Joeri Ruyssinck, V�n Anh Huynh-Thu, Pierre Geurts, Tom Dhaene, Piet Demeester and Yvan Saeys. Submitted to BMC Bioinformatics.

If you are experiencing problems with the software, please don't hesitate to contact us
Contact

    Author: Joeri Ruyssinck
    Department of Information Technology, Internet Based Communication Networks and Services (IBCN), Ghent University - iMinds
    Email: joeri.ruyssinck@intec.ugent.be 

License
The software is published under the GNU GENERAL PUBLIC LICENSE (Copyright (C) 2007 Free Software Foundation), of which a copy is included with the software. Alternatively, you can find the license here.
Disclaimer

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.


DEPENDENCIES:
Following R-packages should be installed: glmnet, randomForest, e1071, ROCR


example.R contains an example run of the NIMEFI algorithm on an artificial expression dataset generated using GeneNetWeaver* 

This example file reads an expression dataset and a list of potential transcription factors (empty file= all genes are considered TF). 
Next it will run E-SVM and GENIE3 and combine the results. Finally, AUROC and AUPR scores are calculated for the resulting prediction.

Set the R current working directory to same directory which contains the .R files.

* Schaffter, T. et al. (2011). GeneNetWeaver: In silico benchmark generation and performance profiling of network inference methods. Bioinformatics, 27(16):2263-70
* Generating realistic in silico gene networks for performance assessment of reverse engineering methods. Marbach D, Schaffter T, Mattiussi C, and Floreano D.Journal of Computational Biology, 16(2):229-239, 2009