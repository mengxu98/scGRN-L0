
# Author: Joeri Ruyssinck (joeri.ruyssinck@intec.ugent.be)

# Following packages should be installed:

# glmnet, randomForest, e1071, ROCR


###############################################################################



# Load all the script files
source("nimefi_main.R")


# Read the expression dataset
expression_dataset <- constructExpressionMatrixFromFile("exampleData/expression_dataset.txt")

# Optional: Read a list of TF
tf <- getIndicesOfGenesInMatrix(expression_dataset,inputFile="")

# Run algorithm using default settings, writes result to output.txt
NIMEFI(expression_dataset,GENIE=TRUE,SVM=TRUE,EL=FALSE,outputFileName = "output/output.txt")
# Calculate AUROC/AUPR
evaluationObject <- prepareEval("output/output.txt","exampleData/gold.tsv")
# Print AUROC/AUPR
calcAUROC(evaluationObject)
calcAUPR(evaluationObject)

