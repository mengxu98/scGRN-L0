for param in {0..17}
do
    sbatch test_THP-1-kt-${param}.job
done