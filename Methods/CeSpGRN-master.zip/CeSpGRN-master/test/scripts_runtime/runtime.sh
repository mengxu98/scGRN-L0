for i in {15..29}
do 
    sbatch test_runtime_${i}.job
done